import {
  Text,
  View,
  StyleSheet,
  TouchableOpacity,
  TextInput,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';

export default function Hinh2() {
  return (
    <LinearGradient
      colors={['#F0FFFF', '#D6F5F5', '#B2EBF2', '#00CCF9']} // trên → giữa → dưới
      start={{ x: 0.5, y: 0 }}
      end={{ x: 0.5, y: 1 }}
      style={styles.container}>
      <View style={styles.top}>
        <Text style={styles.title}>CODE</Text>
      </View>

      <View style={styles.middle}>
        <Text style={styles.subtitle}>VERIFICATION</Text>
        <Text style={styles.textcontent}>
          Enter ontime password sent on ++849092605798
        </Text>
        {/* 6 ô nhập mã */}
        <View style={styles.otpContainer}>
          {Array.from({ length: 6 }).map(() => (
            <View>
              <TextInput
                style={styles.otpBox}
                keyboardType="numeric"
                maxLength={1}
              />
            </View>
          ))}
        </View>
      </View>

      <View style={styles.bottom}>
        <TouchableOpacity style={styles.button}>
          <Text style={styles.buttonText}>VERIFY CODE</Text>
        </TouchableOpacity>
      </View>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#00CCF9',
    padding: 20,
  },
  top: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  middle: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  bottom: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 20,
  },
  title: {
    fontSize: 60,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  subtitle: {
    fontSize: 22,
    fontWeight: 'bold',
    textAlign: 'center',
    marginTop: 15,
    marginBottom: 30,
  },
  textcontent: {
    fontWeight: 'bold',
    textAlign: 'center',
  },
  otpContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginVertical: 20,
  },
  otpBox: {
    borderWidth: 1,
    borderColor: '#000',
    width: 45,
    height: 45,
    marginHorizontal: 5,
    textAlign: 'center',
    fontSize: 20,
    fontWeight: 'bold',
    backgroundColor: '#fff',
  },
  button: {
    backgroundColor: '#FFC107',
    paddingVertical: 12,
    paddingHorizontal: 90,
    marginHorizontal: 10,
  },
  buttonText: {
    fontWeight: 'bold',
    color: '#000',
    fontSize: 20,
  },
});
