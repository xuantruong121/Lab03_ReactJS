import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  Image,
} from 'react-native';
import { Ionicons, FontAwesome } from '@expo/vector-icons';

export default function Hinh8() {
  return (
    <View style={styles.container}>
      <Image
        source={require('../assets/eyeball.png')} 
        style={styles.logo}
      />

      {/* Username */}
      <View style={styles.inputContainer}>
        <Ionicons name="person-outline" size={22} color="#4169E1" style={styles.icon} />
        <TextInput
          style={styles.input}
          placeholder="Please input user name"
          placeholderTextColor="#888"
        />
      </View>

      {/* Password */}
      <View style={styles.inputContainer}>
        <Ionicons name="lock-closed-outline" size={22} color="#4169E1" style={styles.icon} />
        <TextInput
          style={styles.input}
          placeholder="Please input password"
          placeholderTextColor="#888"
          secureTextEntry={true}
        />
      </View>

      {/* Login button */}
      <TouchableOpacity style={styles.loginButton}>
        <Text style={styles.loginButtonText}>LOGIN</Text>
      </TouchableOpacity>

      {/* Register + Forgot Password */}
      <View style={styles.row}>
        <TouchableOpacity>
          <Text style={styles.linkText}>Register</Text>
        </TouchableOpacity>
        <TouchableOpacity>
          <Text style={styles.linkText}>Forgot Password</Text>
        </TouchableOpacity>
      </View>

      {/* Other login methods */}
      <View style={styles.divider}>
        <View style={styles.line} />
        <Text style={styles.dividerText}>Other Login Methods</Text>
        <View style={styles.line} />
      </View>

      <View style={styles.methods}>
        <TouchableOpacity style={[styles.methodBox, { backgroundColor: '#00BFFF' }]}>
          <Ionicons name="person-add" size={28} color="#fff" />
        </TouchableOpacity>
        <TouchableOpacity style={[styles.methodBox, { backgroundColor: '#FFA500' }]}>
          <Ionicons name="wifi" size={28} color="#fff" />
        </TouchableOpacity>
        <TouchableOpacity style={[styles.methodBox, { backgroundColor: '#3b5998' }]}>
          <FontAwesome name="facebook" size={28} color="#fff" />
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    borderWidth: 1,
    borderColor: '#00BFFF',
    alignItems: 'center',
    padding: 20,
    backgroundColor: '#fff',
  },
  logo: {
    width: 100,
    height: 100,
    marginVertical: 30,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    borderBottomWidth: 1,
    borderBottomColor: '#ccc',
    marginVertical: 12,
    width: '100%',
    paddingBottom: 5,
  },
  icon: {
    marginRight: 8,
  },
  input: {
    flex: 1,
    fontSize: 16,
    color: '#000',
  },
  loginButton: {
    marginTop: 20,
    backgroundColor: '#1E90FF',
    paddingVertical: 14,
    width: '100%',
    alignItems: 'center',
    borderRadius: 4,
  },
  loginButtonText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#fff',
  },
  row: {
    marginTop: 15,
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '100%',
    paddingHorizontal: 20,
  },
  linkText: {
    fontSize: 16,
    color: '#000',
  },
  divider: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 25,
  },
  line: {
    flex: 1,
    height: 1,
    backgroundColor: '#4169E1',
  },
  dividerText: {
    marginHorizontal: 8,
    fontSize: 14,
    color: '#4169E1',
  },
  methods: {
    flexDirection: 'row',
    justifyContent: 'center',
  },
  methodBox: {
    width: 60,
    height: 60,
    borderRadius: 10,
    justifyContent: 'center',
    alignItems: 'center',
    marginHorizontal: 10,
  },
});
