import {
  Text,
  View,
  StyleSheet,
  Image,
  TouchableOpacity,
  TextInput,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';

export default function Hinh2() {
  return (
    <View style={styles.container}>
      <View style={styles.top}>
        <Text style={styles.title}>LOGIN</Text>
      </View>

      <View style={styles.middle1}>
        <TextInput
          style={styles.emailInput}
          placeholder="Email"
          placeholderTextColor="#000"
          keyboardType="email-address"
          autoCapitalize="none"
          autoCorrect={false}
        />

        <TextInput
          style={styles.passInput}
          placeholder="Password"
          placeholderTextColor="#000"
          secureTextEntry={true}
        />
      </View>

      <View style={styles.middle2}>
        <TouchableOpacity style={styles.button}>
          <Text style={styles.buttonText}>LOGIN</Text>
        </TouchableOpacity>

        <Text style={{ marginBottom: 7, marginTop: 7 }}>
          When you agree to terms and conditions
        </Text>

        <TouchableOpacity style={{ marginBottom: 7 }}>
          <Text style={{ color: 'purple', fontWeight: 'bold' }}>
            Forgot your password?
          </Text>
        </TouchableOpacity>

        <Text>Or login with</Text>
      </View>

      <View style={styles.bottom}>
        <TouchableOpacity>
          <Image
            style={styles.imgButton}
            source={require('../assets/icon-fb.png')}
          />
        </TouchableOpacity>
        <TouchableOpacity>
          <Image
            style={styles.imgButton}
            source={require('../assets/icon-zalo.png')}
          />
        </TouchableOpacity>
        <TouchableOpacity>
          <Image
            style={styles.imgButton}
            source={require('../assets/icon-gg.png')}
          />
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#D8EFDE',
  },
  top: {
    flex: 1,
    justifyContent: 'center',
  },
  middle1: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  middle2: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  bottom: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 20,
  },
  emailInput: {
    fontSize: 16,
    color: '#000',
    backgroundColor: '#C9E0D0',
    margin: 5,
    padding: 8,
    width: 300,
  },
  passInput: {
    fontSize: 16,
    color: '#000',
    backgroundColor: '#C9E0D0',
    margin: 5,
    padding: 8,
    width: 300,
  },
  title: {
    fontSize: 50,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  button: {
    backgroundColor: '#C34E3B',
    paddingVertical: 12,
    width: 300,
    alignItems: 'center',
  },
  buttonText: {
    fontWeight: 'bold',
    color: 'white',
    fontSize: 20,
  },
  imgButton: {
    width: 110,
    height: 50,
  },
});
