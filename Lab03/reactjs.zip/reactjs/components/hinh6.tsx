import {
  Text,
  View,
  StyleSheet,
  TextInput,
  TouchableOpacity,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useState } from 'react';

export default function RegisterScreen() {
  const [gender, setGender] = useState(null);

  return (
    <View style={styles.container}>
      <View style={styles.top}>
        <Text style={styles.title}>REGISTER</Text>
      </View>

      <View style={styles.middle}>
        <TextInput
          style={styles.input}
          placeholder="Name"
          placeholderTextColor="#000"
        />
        <TextInput
          style={styles.input}
          placeholder="Phone"
          placeholderTextColor="#000"
          keyboardType="phone-pad"
        />
        <TextInput
          style={styles.input}
          placeholder="Email"
          placeholderTextColor="#000"
          keyboardType="email-address"
        />

        <TextInput
          style={styles.passInput}
          placeholder="Password"
          placeholderTextColor="#000"
          secureTextEntry={true}
        />

        <TextInput
          style={styles.input}
          placeholder="Birthday"
          placeholderTextColor="#000"
        />
      </View>

      <View style={styles.genderContainer}>
        <TouchableOpacity
          style={styles.genderOption}
          onPress={() => setGender('male')}>
          <Ionicons
            name={gender === 'male' ? 'radio-button-on' : 'radio-button-off'}
            size={22}
            color={gender === 'male' ? '#C34E3B' : '#000'}
          />
          <Text style={styles.genderText}>Male</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.genderOption}
          onPress={() => setGender('female')}>
          <Ionicons
            name={gender === 'female' ? 'radio-button-on' : 'radio-button-off'}
            size={22}
            color={gender === 'female' ? '#C34E3B' : '#000'}
          />
          <Text style={styles.genderText}>Female</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.bottom}>
        <TouchableOpacity style={styles.button}>
          <Text style={styles.buttonText}>REGISTER</Text>
        </TouchableOpacity>
        <Text style={{ marginTop: 8 }}>
          When you agree to terms and conditions
        </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#D8EFDE',
    padding: 20,
  },
  top: {
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 30,
    marginBottom: 20,
  },
  title: {
    fontSize: 40,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  middle: {
    alignItems: 'center',
  },
  input: {
    fontSize: 16,
    color: '#000',
    backgroundColor: '#C9E0D0',
    marginVertical: 6,
    padding: 10,
    width: 320,
  },
  passInput: {
    fontSize: 16,
    color: '#000',
    backgroundColor: '#C9E0D0',
    marginVertical: 6,
    padding: 10,
    width: 320,
  },
  genderContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginVertical: 15,
  },
  genderOption: {
    flexDirection: 'row',
    alignItems: 'center',
    marginHorizontal: 15,
  },
  genderText: {
    marginLeft: 5,
    fontSize: 16,
  },
  bottom: {
    alignItems: 'center',
    marginTop: 10,
  },
  button: {
    backgroundColor: '#C34E3B',
    paddingVertical: 12,
    width: 320,
    alignItems: 'center',
  },
  buttonText: {
    fontWeight: 'bold',
    color: 'white',
    fontSize: 20,
  },
});
