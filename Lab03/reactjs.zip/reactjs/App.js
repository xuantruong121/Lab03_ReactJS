import Hinh1 from './components/hinh1'
import Hinh2 from './components/hinh2'
import Hinh3 from './components/hinh3'
import Hinh4 from './components/hinh4'
import Hinh5 from './components/hinh5'
import Hinh6 from './components/hinh6'
import Hinh7 from './components/hinh7'
import Hinh8 from './components/hinh8'

export default function App() {
  return (
    //<Hinh1></Hinh1>
    //<Hinh2></Hinh2>
    //<Hinh3></Hinh3>
    // <Hinh4></Hinh4>
    // <Hinh5></Hinh5>
    // <Hinh6></Hinh6>
    <Hinh7></Hinh7>
    // <Hinh8></Hinh8>
   )
}
