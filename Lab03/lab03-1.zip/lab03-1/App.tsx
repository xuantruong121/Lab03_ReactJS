import React from 'react';
import Hinh1 from './components/hinh1.tsx'

export default function App() {
  return (
    <Hinh1 ></Hinh1>
   )
}
