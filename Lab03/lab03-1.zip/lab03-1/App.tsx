import Hinh1 from './components/hinh1.tsx'
import Hinh2 from './components/hinh2.tsx'
import Hinh3 from './components/hinh3.tsx'
import Hinh4 from './components/hinh4.tsx'

export default function App() {
  return (
    //<Hinh1></Hinh1>
    //<Hinh2></Hinh2>
    //<Hinh3></Hinh3>
    <Hinh4></Hinh4>
   )
}
